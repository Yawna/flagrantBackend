def main(event, context):
    print(event)
    print(context)

